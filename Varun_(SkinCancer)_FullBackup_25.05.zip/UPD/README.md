# Streamlit NavBar.  
### [A version without flask can be found here](https://github.com/BugzTheBunny/streamlit-navbar-flaskless)

An example of how to make an streamlit app with a navbar.

Using:

`streamlit` tested on => 0.84.0

`bootstrap 4` 

![snapshot](https://user-images.githubusercontent.com/44586585/125415916-a4a5f1b9-9eae-4aa5-99bc-9399062e54b7.gif)
